# 3D Carousel Using TweenMax.js & jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/eaczwuho-the-decoder/pen/PoVLPGZ](https://codepen.io/eaczwuho-the-decoder/pen/PoVLPGZ).

Wanted to explore some 3d carousel goodness, using DOM elements. Works best in Chrome/Safari, then FF, not 100% sure about IE 10.

TO DO: Adding touch interaction with devices & animate into place and out.

NOTE: 5/29/17 -This looks different. This pen is really old and since the move from http:// to https:// i've lost some references to fonts and images and whatnot. working to get that re-established. Until then, you get the point of it!